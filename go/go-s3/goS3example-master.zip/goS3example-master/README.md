# Use AWS S3 with Golang 
Example for connecting, uploading, downloading and listing files from an AWS S3 Bucket with Golang

## More Information

Read more: 
- AWS SDK for Go v2: https://asanchez.dev/blog/amazon-s3-v2-golang/
- AWS SDK for Go v1 (deprecated): https://asanchez.dev/blog/upload-to-amazon-s3-with-golang

## License
[MIT](https://choosealicense.com/licenses/mit/)
