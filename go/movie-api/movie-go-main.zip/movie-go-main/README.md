# Movie Go

For details please check to [my blog post](https://medium.com/@dilaragorum/lets-build-a-movie-api-with-clean-architecture-ef1f555b563d)